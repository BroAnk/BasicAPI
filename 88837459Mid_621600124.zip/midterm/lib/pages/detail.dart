import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';

class detail extends StatefulWidget {
  const detail({Key? key}) : super(key: key);

  @override
  _detailState createState() => _detailState();
}

class _detailState extends State<detail> {
  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      Center(
        child: Padding(
          padding: const EdgeInsets.all(50.0),
          child: Column(
            children: [],
          ),
        ),
      )
    ]);
  }
}

Future getData() async {
  //https://raw.githubusercontent.com/wantanasisomboon/BasicAPI/main/data2.json
  var url = Uri.https(
      'raw.githubusercontent.com', '/BroAnk/BasicAPI/main/midtermtest.json');
  var response = await http.get(url);
  var result = json.decode(response.body);
  return result;
}
