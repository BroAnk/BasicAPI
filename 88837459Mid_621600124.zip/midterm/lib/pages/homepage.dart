import 'package:flutter/material.dart';

class homepage extends StatefulWidget {
  const homepage({Key? key}) : super(key: key);

  @override
  _homepageState createState() => _homepageState();
}

class _homepageState extends State<homepage> {
  sampleFunction() {
    // TODO: implement initState
    TextEditingController name = TextEditingController();
    print("Nattakorn");
  }

  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      Center(
        child: Padding(
          padding: const EdgeInsets.all(50.0),
          child: Column(
            children: [
              Image.network(
                'https://images.pexels.com/photos/2882566/pexels-photo-2882566.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
                width: 300,
              ),
              Text(' '),
              const Text(
                'Login เข้าสู่ระบบ',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
              ),
              Text(' '),
              Text(' '),
              TextField(
                // controller: name,
                decoration: InputDecoration(
                    labelText: 'Username', //textbox 2nd
                    border: OutlineInputBorder()),
              ),
              SizedBox(
                height: 30,
              ),
              TextField(
                // controller: quantity,
                decoration: InputDecoration(
                    labelText: 'Password', //textbox 2nd
                    border: OutlineInputBorder()),
              ),
              SizedBox(
                height: 30,
              ),
              TextButton(
                style: TextButton.styleFrom(
                  primary: Colors.blue,
                ),
                onPressed: sampleFunction,
                child: Text('เข้าสู่ระบบ'),
              ),
              const Text(
                'ยินดีต้อนรับ Nattakorn',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
            ],
          ),
        ),
      )
    ]);
  }
}
